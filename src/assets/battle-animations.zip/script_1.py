
# Создам дополнительную таблицу с визуальными эффектами
import csv

visual_effects_comparison = [
    {
        'Элемент': 'Подготовка карты',
        'Успешная атака': 'Scale 1.1x, легкое свечение',
        'Блокировка': 'Scale 1.1x, легкое свечение',
        'Критическая атака': 'Scale 1.2-1.3x, интенсивное свечение + молнии'
    },
    {
        'Элемент': 'Трейл-эффект',
        'Успешная атака': 'Средний трейл, красный/синий',
        'Блокировка': 'Средний трейл',
        'Критическая атака': 'Толстый яркий трейл с искажением воздуха'
    },
    {
        'Элемент': 'Момент удара',
        'Успешная атака': 'Вспышка, небольшой knockback',
        'Блокировка': 'Щит-эффект, bounce обратно',
        'Критическая атака': 'Полноэкранная вспышка, сильный knockback'
    },
    {
        'Элемент': 'Тряска экрана',
        'Успешная атака': '2-3px (легкая)',
        'Блокировка': 'Нет или 1-2px',
        'Критическая атака': '8-12px (сильная)'
    },
    {
        'Элемент': 'Частицы',
        'Успешная атака': '10-15 частиц, средняя скорость',
        'Блокировка': '15-20 частиц вверх (искры от щита)',
        'Критическая атака': '30-50 частиц, радиальный взрыв'
    },
    {
        'Элемент': 'Текст урона',
        'Успешная атака': 'Средний размер, красный, движение вверх',
        'Блокировка': 'Текст "БЛОК" синий/золотой',
        'Критическая атака': 'БОЛЬШОЙ размер + "КРИТ!", золотой, с explosion эффектом'
    },
    {
        'Элемент': 'Вспышка экрана',
        'Успешная атака': '20-30% white overlay',
        'Блокировка': '10-20% blue overlay',
        'Критическая атака': '40-60% white/gold overlay'
    },
    {
        'Элемент': 'Цветовая схема',
        'Успешная атака': 'Красный #FF4444, оранжевый #FF8844',
        'Блокировка': 'Синий #4444FF, голубой #88CCFF, золотой #FFD700',
        'Критическая атака': 'Красный #FF0000, оранжевый #FFAA00, золотой #FFD700, пурпурный #FF00FF'
    },
    {
        'Элемент': 'Звуковые эффекты',
        'Успешная атака': 'Whoosh -> Impact -> Hurt звук',
        'Блокировка': 'Whoosh -> Металлический лязг/барьер',
        'Критическая атака': 'Charge up -> Мощный impact -> Джингл крита -> Explosion'
    },
    {
        'Элемент': 'Общая длительность',
        'Успешная атака': '1.0-1.4 сек',
        'Блокировка': '1.1-1.3 сек',
        'Критическая атака': '1.8-2.3 сек'
    },
    {
        'Элемент': 'Специальные эффекты',
        'Успешная атака': 'HP бар уменьшается плавно',
        'Блокировка': 'Эффект щита, отскок атаки',
        'Критическая атака': 'Slow motion, chromatic aberration, множественные вспышки'
    }
]

# Сохраним сравнительную таблицу
with open('visual_effects_comparison.csv', 'w', encoding='utf-8-sig', newline='') as f:
    writer = csv.DictWriter(f, fieldnames=['Элемент', 'Успешная атака', 'Блокировка', 'Критическая атака'])
    writer.writeheader()
    writer.writerows(visual_effects_comparison)

print("✓ Сравнительная таблица визуальных эффектов сохранена\n")

# Создадим также практические примеры реализации
implementation_examples = """
=== ПРИМЕРЫ РЕАЛИЗАЦИИ АНИМАЦИЙ ===

1. БИБЛИОТЕКИ И ИНСТРУМЕНТЫ:
   • DoTween (Unity) - для плавных анимаций карт
   • Particle System - для эффектов частиц
   • Shader Graph - для свечений и вспышек
   • Timeline - для сложных последовательностей
   • Cinemachine - для тряски камеры

2. ПСЕВДОКОД УСПЕШНОЙ АТАКИ:

   function PlaySuccessfulAttack(attackerCard, targetCard, damage):
       // Этап 1: Подготовка
       attackerCard.ScaleTo(1.1, 0.2, EaseOutQuad)
       attackerCard.GlowEffect(color: red, intensity: 0.5, duration: 0.2)
       PlaySound("whoosh")
       Wait(0.2)
       
       // Этап 2: Траектория
       trailEffect = SpawnTrail(from: attackerCard, to: targetCard, color: red)
       SpawnParticles(path: trailEffect, count: 15, speed: fast)
       Wait(0.3)
       
       // Этап 3: Удар
       targetCard.Shake(intensity: medium, duration: 0.2)
       CameraShake(pixels: 3, duration: 0.15)
       FlashScreen(intensity: 0.3, duration: 0.1)
       SpawnImpactParticles(at: targetCard, count: 20, direction: radial)
       PlaySound("impact")
       Wait(0.2)
       
       // Этап 4: Урон
       ShowDamageText(damage, color: red, size: large, motion: upward)
       targetCard.HPBar.AnimateDecrease(to: newHP, duration: 0.3)
       targetCard.FlashRed(intensity: 0.6, duration: 0.3)
       PlaySound("hurt")
       Wait(0.3)
       
       // Возврат к нормальному состоянию
       attackerCard.ScaleTo(1.0, 0.15, EaseInQuad)

3. ПСЕВДОКОД БЛОКИРОВКИ:

   function PlayBlockedAttack(attackerCard, defenderCard):
       // Подготовка и траектория аналогичны
       attackerCard.ScaleTo(1.1, 0.2, EaseOutQuad)
       Wait(0.2)
       
       trailEffect = SpawnTrail(from: attackerCard, to: defenderCard)
       Wait(0.3)
       
       // Блок
       shield = SpawnShield(at: defenderCard, color: blue_gold)
       shield.PopIn(duration: 0.1, scale: from 0 to 1.2)
       
       // Столкновение с щитом
       SpawnImpactSparks(at: shield, count: 25, direction: upward)
       trailEffect.Bounce(back: true, distance: 30%)
       attackerCard.Recoil(distance: 20px, duration: 0.2)
       PlaySound("metal_clang")
       
       // Текст блока
       ShowText("БЛОК!", at: defenderCard, color: blue, size: large)
       Wait(0.3)
       
       // Щит исчезает
       shield.FadeOut(duration: 0.2)
       defenderCard.GlowEffect(color: blue, intensity: 0.4, duration: 0.3)

4. ПСЕВДОКОД КРИТИЧЕСКОЙ АТАКИ:

   function PlayCriticalAttack(attackerCard, targetCard, damage):
       // Усиленная подготовка
       TimeScale = 0.7  // Замедление времени
       attackerCard.ScaleTo(1.3, 0.3, ElasticOut)
       attackerCard.GlowEffect(color: red_yellow, intensity: 1.0, duration: 0.3)
       SpawnLightning(around: attackerCard, count: 5)
       PlaySound("charge_up")
       Wait(0.3)
       
       // Усиленная траектория
       trailEffect = SpawnThickTrail(from: attackerCard, to: targetCard, 
                                     gradient: [red, orange, yellow])
       SpawnParticles(path: trailEffect, count: 40, speed: very_fast)
       DistortionEffect(along: trailEffect, intensity: high)
       DarkenBackground(amount: 0.4)
       Wait(0.4)
       
       // КРИТИЧЕСКИЙ УДАР
       TimeScale = 0.5  // Еще медленнее
       FlashScreen(intensity: 0.6, duration: 0.2, color: white)
       CameraShake(pixels: 12, duration: 0.3)
       SpawnRadialExplosion(at: targetCard, particles: 50, radius: large)
       targetCard.Knockback(distance: 40px, duration: 0.3)
       SpawnLightning(at: targetCard, count: 3)
       SpawnStars(around: targetCard, count: 10)
       PlaySound("critical_impact")
       PlaySound("explosion")
       Wait(0.3)
       
       // Драматичный урон
       TimeScale = 1.0  // Возврат к нормальной скорости
       ShowText("КРИТИЧЕСКИЙ УДАР!", size: extra_large, 
                color: gold, effect: explosion_scale)
       ShowDamageText(damage, color: gold_red, size: huge, 
                      motion: upward_with_shake, effect: glow)
       targetCard.HPBar.AnimateDecrease(to: newHP, duration: 0.4, 
                                        effect: glow_red)
       targetCard.FlashRed(intensity: 0.8, repeat: 3, duration: 0.5)
       
       // Длительные эффекты
       ContinuousSparks(at: targetCard, duration: 0.5)
       PlayJingle("critical_hit_jingle")
       Wait(0.5)
       
       // Финал
       FadeAllEffects(duration: 0.3)
       CameraResetPosition(duration: 0.2)
       FinalFlash(intensity: 0.3, duration: 0.1)

5. ОПТИМИЗАЦИЯ ДЛЯ МОБИЛЬНЫХ УСТРОЙСТВ:

   if (DevicePerformance == LOW):
       particleCount *= 0.5
       disableBlurEffects()
       disableDistortionEffects()
       animationDuration *= 0.7
       
   if (BatterySavingMode == ON):
       particleCount *= 0.3
       disableScreenShake()
       disableGlowEffects()
       simplifyTrailEffects()

6. АДАПТИВНОЕ УПРАВЛЕНИЕ КАЧЕСТВОМ:

   function AdjustEffectsQuality():
       fps = GetCurrentFPS()
       
       if fps < 30:
           ReduceParticleCount(by: 50%)
           DisableNonEssentialEffects()
       
       if fps < 20:
           SwitchToMinimalEffects()
           
       if fps > 50 && QualityLevel < HIGH:
           IncreaseEffectQuality()
"""

print(implementation_examples)

print("\n" + "="*70)
print("СОЗДАНИЕ ФИНАЛЬНОГО ДОКУМЕНТА")
print("="*70)
