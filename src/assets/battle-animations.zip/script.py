
# Создам структурированный документ с описанием анимаций для карточной игры
# Основываясь на макете игры и лучших практиках из исследованных источников

animation_concepts = {
    "successful_attack": {
        "name": "Успешная атака",
        "stages": [
            {
                "stage": 1,
                "name": "Подготовка",
                "duration": "0.2-0.3 сек",
                "description": "Карта атакующего слегка увеличивается (scale 1.1x) и подсвечивается",
                "effects": ["Свечение контура карты", "Легкая пульсация", "Звук 'whoosh'"]
            },
            {
                "stage": 2,
                "name": "Траектория",
                "duration": "0.3-0.4 сек",
                "description": "Визуальный эффект перемещения от атакующего к цели",
                "effects": [
                    "Трейл-эффект от карты к цели",
                    "Частицы энергии вдоль траектории",
                    "Цвет зависит от типа атаки (красный для физической, синий для магической)"
                ]
            },
            {
                "stage": 3,
                "name": "Удар",
                "duration": "0.2-0.25 сек",
                "description": "Момент попадания по цели",
                "effects": [
                    "Вспышка на карте противника",
                    "Карта цели отклоняется назад (shake/knockback)",
                    "Партиклы разлетаются от точки удара",
                    "Screen shake (легкая тряска экрана)",
                    "Звук удара (impact)"
                ]
            },
            {
                "stage": 4,
                "name": "Урон",
                "duration": "0.3-0.4 сек",
                "description": "Отображение урона и обратная связь",
                "effects": [
                    "Всплывающий текст с цифрами урона (красный цвет, движение вверх с затуханием)",
                    "HP бар цели анимированно уменьшается",
                    "Красная вспышка по краям карты жертвы",
                    "Звук получения урона"
                ]
            }
        ],
        "total_duration": "1.0-1.4 сек",
        "color_scheme": ["#FF4444", "#FF8844", "#FFFFFF"],
        "priority": "high"
    },
    
    "blocked_attack": {
        "name": "Блокировка атаки",
        "stages": [
            {
                "stage": 1,
                "name": "Подготовка атаки",
                "duration": "0.2-0.3 сек",
                "description": "Аналогично успешной атаке - подготовка",
                "effects": ["Карта атакующего увеличивается", "Начальное свечение"]
            },
            {
                "stage": 2,
                "name": "Траектория к цели",
                "duration": "0.3 сек",
                "description": "Атака движется к цели",
                "effects": ["Трейл эффект", "Частицы энергии"]
            },
            {
                "stage": 3,
                "name": "Блок",
                "duration": "0.3-0.4 сек",
                "description": "Момент блокировки удара",
                "effects": [
                    "Щит-эффект появляется перед картой защитника (синий/золотой)",
                    "Блеск и искры от столкновения со щитом",
                    "Атака 'отскакивает' обратно (bounce effect)",
                    "Текст 'БЛОК' или 'ЗАЩИТА' появляется над защитником",
                    "Звук металлического лязга или барьера"
                ]
            },
            {
                "stage": 4,
                "name": "Последствия",
                "duration": "0.3 сек",
                "description": "Визуальная обратная связь о блоке",
                "effects": [
                    "Карта защитника слегка светится (показывает успешную защиту)",
                    "Частицы рассеиваются",
                    "Карта атакующего возвращается в нормальное состояние с легким 'отталкиванием'"
                ]
            }
        ],
        "total_duration": "1.1-1.3 сек",
        "color_scheme": ["#4444FF", "#88CCFF", "#FFD700", "#FFFFFF"],
        "visual_elements": ["Энергетический щит", "Искры", "Символы защиты"],
        "priority": "high"
    },
    
    "critical_attack": {
        "name": "Критическая атака",
        "stages": [
            {
                "stage": 1,
                "name": "Подготовка (усиленная)",
                "duration": "0.3-0.4 сек",
                "description": "Более драматичная подготовка, показывающая важность удара",
                "effects": [
                    "Карта атакующего сильно увеличивается (scale 1.2-1.3x)",
                    "Интенсивное красно-желтое свечение",
                    "Искры и молнии вокруг карты",
                    "Время замедляется (slow-motion effect)",
                    "Предупредительный звук (charge up)"
                ]
            },
            {
                "stage": 2,
                "name": "Траектория (усиленная)",
                "duration": "0.4-0.5 сек",
                "description": "Мощный визуальный эффект перемещения",
                "effects": [
                    "Толстый яркий трейл (красный-оранжевый градиент)",
                    "Множество энергетических частиц",
                    "Искажение воздуха вдоль траектории",
                    "Возможен луч или молния",
                    "Экран слегка затемняется, фокус на атаке"
                ]
            },
            {
                "stage": 3,
                "name": "Критический удар",
                "duration": "0.3-0.4 сек",
                "description": "Драматичный момент попадания",
                "effects": [
                    "Мощная вспышка (весь экран)",
                    "Радиальный взрыв частиц от точки удара",
                    "Сильный knockback - карта цели значительно отклоняется",
                    "Сильная тряска экрана",
                    "Молниеносные эффекты",
                    "Звездочки/символы разлетаются",
                    "Громкий импактный звук + визг"
                ]
            },
            {
                "stage": 4,
                "name": "Отображение урона (драматичное)",
                "duration": "0.5-0.6 сек",
                "description": "Максимальная визуальная обратная связь",
                "effects": [
                    "БОЛЬШОЙ текст 'КРИТИЧЕСКИЙ УДАР!' или 'КРИТ!' (золотой/красный)",
                    "Цифры урона появляются крупнее и ярче (с эффектом explosion)",
                    "Множественные всплывающие текстовые эффекты",
                    "HP бар быстро уменьшается с дополнительным свечением",
                    "Карта жертвы мигает красным несколько раз",
                    "Длительное послесвечение",
                    "Дополнительные визуальные элементы (звезды, молнии, искры продолжают падать)"
                ]
            },
            {
                "stage": 5,
                "name": "Эпический финал",
                "duration": "0.3 сек",
                "description": "Завершающий эффект",
                "effects": [
                    "Все эффекты постепенно затухают",
                    "Камера возвращается в нормальное положение",
                    "Финальная вспышка перед исчезновением эффектов"
                ]
            }
        ],
        "total_duration": "1.8-2.3 сек",
        "color_scheme": ["#FF0000", "#FFAA00", "#FFD700", "#FFFFFF", "#FF00FF"],
        "special_effects": [
            "Slow motion",
            "Screen flash",
            "Screen shake (strong)",
            "Радиальный blur",
            "Chromatic aberration",
            "Частицы-звезды"
        ],
        "audio": ["Charge sound", "Powerful impact", "Critical hit jingle", "Explosion"],
        "priority": "very_high",
        "rarity": "should_feel_special"
    }
}

# Дополнительные рекомендации
additional_recommendations = {
    "timing_guidelines": {
        "fast_attacks": "0.8-1.2 сек (быстрые удары, низкий урон)",
        "normal_attacks": "1.0-1.5 сек (стандартные атаки)",
        "heavy_attacks": "1.5-2.0 сек (мощные атаки)",
        "critical_hits": "1.8-2.5 сек (особые моменты)"
    },
    
    "visual_hierarchy": {
        "most_important": "Момент удара и цифры урона",
        "secondary": "Траектория атаки и подготовка",
        "tertiary": "Окружающие эффекты и частицы"
    },
    
    "color_coding": {
        "physical_damage": "#FF4444 (красный)",
        "magical_damage": "#4444FF (синий)",
        "critical_hit": "#FFD700 (золотой)",
        "blocked": "#88CCFF (светло-синий)",
        "healing": "#44FF44 (зеленый)",
        "poison_dark": "#9944FF (фиолетовый)"
    },
    
    "particle_systems": {
        "success": "Искры, летящие наружу",
        "block": "Искры, отскакивающие вверх",
        "critical": "Взрыв с радиальным разлетом",
        "miss": "Дым, рассеивающийся"
    },
    
    "screen_effects": {
        "light_shake": "Для обычных атак (2-3px движение)",
        "medium_shake": "Для сильных атак (4-6px)",
        "heavy_shake": "Для критов (8-12px)",
        "flash_intensity": "От 20% до 60% white overlay"
    },
    
    "animation_curves": {
        "ease_in": "Для подготовки атаки",
        "ease_out": "Для замедления после удара",
        "ease_in_out": "Для плавных переходов",
        "bounce": "Для эффектов отскока при блоке",
        "elastic": "Для критических ударов (драматизм)"
    },
    
    "mobile_considerations": {
        "reduce_particles": "На слабых устройствах уменьшить количество частиц",
        "simplify_effects": "Убрать blur и сложные shader эффекты",
        "optimize_duration": "Сократить анимации на 20-30%",
        "battery_saving": "Опция отключения тяжелых эффектов"
    }
}

# Специфичные эффекты для разных типов карт
card_specific_effects = {
    "warrior_card": {
        "attack_style": "Физический удар мечом",
        "effects": ["След клинка", "Металлический блеск", "Искры от металла"],
        "colors": ["#C0C0C0", "#FF4444"],
        "sound": "Звук меча"
    },
    "mage_card": {
        "attack_style": "Магический снаряд",
        "effects": ["Руны вокруг карты", "Магический круг", "Энергетический шар"],
        "colors": ["#4444FF", "#AA44FF", "#44FFFF"],
        "sound": "Магический свист"
    },
    "archer_card": {
        "attack_style": "Выстрел стрелой",
        "effects": ["Летящая стрела с трейлом", "Свист воздуха", "Попадание стрелы"],
        "colors": ["#FFAA44", "#8B4513"],
        "sound": "Свист стрелы + удар"
    },
    "monster_card": {
        "attack_style": "Укус или удар когтями",
        "effects": ["Следы когтей", "Темная энергия", "Брызги"],
        "colors": ["#440044", "#FF0000", "#000000"],
        "sound": "Рычание + удар"
    }
}

print("=== КОНЦЕПЦИЯ АНИМАЦИЙ АТАКИ ДЛЯ КАРТОЧНОЙ ИГРЫ ===\n")
print(f"Общее количество типов анимаций: {len(animation_concepts)}\n")

for anim_type, details in animation_concepts.items():
    print(f"\n{'='*70}")
    print(f"АНИМАЦИЯ: {details['name'].upper()}")
    print(f"{'='*70}")
    print(f"Общая длительность: {details['total_duration']}")
    print(f"Цветовая схема: {', '.join(details['color_scheme'])}")
    print(f"\nЭтапы анимации ({len(details['stages'])} этапов):\n")
    
    for stage in details['stages']:
        print(f"  [{stage['stage']}] {stage['name']} ({stage['duration']})")
        print(f"      {stage['description']}")
        print(f"      Эффекты:")
        for effect in stage['effects']:
            print(f"        • {effect}")
        print()

print(f"\n{'='*70}")
print("ДОПОЛНИТЕЛЬНЫЕ РЕКОМЕНДАЦИИ")
print(f"{'='*70}\n")

for category, items in additional_recommendations.items():
    print(f"\n{category.upper().replace('_', ' ')}:")
    if isinstance(items, dict):
        for key, value in items.items():
            print(f"  • {key}: {value}")
    else:
        print(f"  {items}")

# Сохраним в CSV для удобства
import csv

csv_data = []
for anim_type, details in animation_concepts.items():
    for stage in details['stages']:
        csv_data.append({
            'Тип анимации': details['name'],
            'Этап': stage['stage'],
            'Название этапа': stage['name'],
            'Длительность': stage['duration'],
            'Описание': stage['description'],
            'Эффекты': '; '.join(stage['effects'])
        })

# Сохраним
with open('animation_concepts.csv', 'w', encoding='utf-8-sig', newline='') as f:
    if csv_data:
        writer = csv.DictWriter(f, fieldnames=csv_data[0].keys())
        writer.writeheader()
        writer.writerows(csv_data)

print("\n✓ Данные сохранены в animation_concepts.csv")
print(f"\n✓ Создано {len(csv_data)} детальных описаний анимаций")
