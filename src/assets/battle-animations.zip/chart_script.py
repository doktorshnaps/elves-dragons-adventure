import plotly.graph_objects as go
import plotly.express as px
from plotly.subplots import make_subplots

# Create a flowchart-style diagram using Plotly
fig = go.Figure()

# Define positions for the flowchart nodes
# Start node
fig.add_shape(
    type="circle",
    x0=-0.1, y0=4.9, x1=0.1, y1=5.1,
    fillcolor="#9FA8B0", line=dict(color="#5D878F", width=2)
)
fig.add_annotation(x=0, y=5, text="Start", showarrow=False, font=dict(size=12, color="#13343B"))

# Successful Attack Path (Green)
success_steps = [
    (0, 4, "Card Prep<br>0.2-0.3s"),
    (0, 3, "Trajectory<br>0.3-0.4s"), 
    (0, 2, "Hit Impact<br>0.2-0.25s"),
    (0, 1, "Damage Disp<br>0.3-0.4s"),
    (0, 0, "End")
]

for i, (x, y, text) in enumerate(success_steps):
    if i == len(success_steps) - 1:  # End node
        fig.add_shape(
            type="circle",
            x0=x-0.1, y0=y-0.1, x1=x+0.1, y1=y+0.1,
            fillcolor="#9FA8B0", line=dict(color="#5D878F", width=2)
        )
    else:
        fig.add_shape(
            type="rect",
            x0=x-0.2, y0=y-0.1, x1=x+0.2, y1=y+0.1,
            fillcolor="#A5D6A7", line=dict(color="#2E8B57", width=2)
        )
    fig.add_annotation(x=x, y=y, text=text, showarrow=False, font=dict(size=10, color="#13343B"))

# Blocked Attack Path (Blue)  
blocked_steps = [
    (-1, 4, "Card Prep<br>0.2-0.3s"),
    (-1, 3, "Trajectory<br>0.3s"),
    (-1, 2, "Shield Block<br>0.3-0.4s"), 
    (-1, 1, "Defense Feed<br>0.3s"),
    (-1, 0, "End")
]

for i, (x, y, text) in enumerate(blocked_steps):
    if i == len(blocked_steps) - 1:  # End node
        fig.add_shape(
            type="circle",
            x0=x-0.1, y0=y-0.1, x1=x+0.1, y1=y+0.1,
            fillcolor="#9FA8B0", line=dict(color="#5D878F", width=2)
        )
    else:
        fig.add_shape(
            type="rect",
            x0=x-0.2, y0=y-0.1, x1=x+0.2, y1=y+0.1,
            fillcolor="#B3E5EC", line=dict(color="#1FB8CD", width=2)
        )
    fig.add_annotation(x=x, y=y, text=text, showarrow=False, font=dict(size=10, color="#13343B"))

# Critical Attack Path (Red)
critical_steps = [
    (1, 4, "Enhanced Prep<br>0.3-0.4s"),
    (1, 3, "Enhanced Traj<br>0.4-0.5s"),
    (1, 2, "Critical Hit<br>0.3-0.4s"),
    (1, 1, "Dramatic Dmg<br>0.5-0.6s"),
    (1, 0.5, "Epic Finale<br>0.3s"),
    (1, 0, "End")
]

for i, (x, y, text) in enumerate(critical_steps):
    if i == len(critical_steps) - 1:  # End node
        fig.add_shape(
            type="circle", 
            x0=x-0.1, y0=y-0.1, x1=x+0.1, y1=y+0.1,
            fillcolor="#9FA8B0", line=dict(color="#5D878F", width=2)
        )
    else:
        fig.add_shape(
            type="rect",
            x0=x-0.2, y0=y-0.1, x1=x+0.2, y1=y+0.1,
            fillcolor="#FFCDD2", line=dict(color="#DB4545", width=2)
        )
    fig.add_annotation(x=x, y=y, text=text, showarrow=False, font=dict(size=10, color="#13343B"))

# Add arrows for flow direction
arrows = [
    # Start to each path
    (0, 4.9, -1, 4.1),  # Start to Blocked
    (0, 4.9, 0, 4.1),   # Start to Success  
    (0, 4.9, 1, 4.1),   # Start to Critical
    
    # Success path arrows
    (0, 3.9, 0, 3.1),
    (0, 2.9, 0, 2.1),
    (0, 1.9, 0, 1.1),
    (0, 0.9, 0, 0.1),
    
    # Blocked path arrows
    (-1, 3.9, -1, 3.1),
    (-1, 2.9, -1, 2.1), 
    (-1, 1.9, -1, 1.1),
    (-1, 0.9, -1, 0.1),
    
    # Critical path arrows
    (1, 3.9, 1, 3.1),
    (1, 2.9, 1, 2.1),
    (1, 1.9, 1, 1.1),
    (1, 1.4, 1, 0.6),
    (1, 0.4, 1, 0.1)
]

for x0, y0, x1, y1 in arrows:
    fig.add_annotation(
        x=x1, y=y1,
        ax=x0, ay=y0,
        xref="x", yref="y",
        axref="x", ayref="y", 
        arrowhead=2,
        arrowsize=1,
        arrowwidth=2,
        arrowcolor="#333333",
        showarrow=True
    )

# Add path labels
fig.add_annotation(x=-1, y=4.5, text="BLOCKED ATTACK", showarrow=False, 
                  font=dict(size=14, color="#1FB8CD", family="Arial Black"))
fig.add_annotation(x=0, y=4.5, text="SUCCESSFUL ATTACK", showarrow=False,
                  font=dict(size=14, color="#2E8B57", family="Arial Black"))
fig.add_annotation(x=1, y=4.5, text="CRITICAL ATTACK", showarrow=False,
                  font=dict(size=14, color="#DB4545", family="Arial Black"))

# Update layout
fig.update_layout(
    title="Card Game Attack Sequences",
    showlegend=False,
    xaxis=dict(showgrid=False, zeroline=False, showticklabels=False, range=[-1.5, 1.5]),
    yaxis=dict(showgrid=False, zeroline=False, showticklabels=False, range=[-0.5, 5.5]),
    plot_bgcolor="rgba(0,0,0,0)",
    paper_bgcolor="rgba(0,0,0,0)"
)

# Save the chart
fig.write_image("attack_flowchart.png")
fig.write_image("attack_flowchart.svg", format="svg")
print("Flowchart saved successfully")